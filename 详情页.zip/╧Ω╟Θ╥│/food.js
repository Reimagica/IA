
const images = ['none1.jpg', 'none2.jpg', 'none3.jpg']; // 替换为你的图片路径
let currentIndex = 0;

function moveSlide(step) {
    currentIndex = (currentIndex + step + images.length) % images.length;
    document.querySelector('.picture_food').src = images[currentIndex];
}


var isAdded = 0; // 初始状态为 0 (未添加)

function toggleWishlistStatus() {
    // 切换状态
    isAdded = 1 - isAdded;

    // 更新文本
    var textElement = document.querySelector('.add_heart_list');
    var imageElement = document.getElementById('heartSymbol');

    if (isAdded === 0) {
        textElement.textContent = "添加至心愿单";
        imageElement.src = "add.png"; 
    } else {
        textElement.textContent = "心愿单菜品";
        imageElement.src = "heart.png"; 
    }
}

document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('.food-review-form');
    form.onsubmit = function (e) {
        e.preventDefault(); // 阻止表单的默认提交行为

        // 获取用户的评价
        var review = document.getElementById('user_review').value;

        // 检查评价内容是否为空
        if (review.trim() === '') {
            alert('请填写菜品评价！');
            return;
        }

        // 在这里可以添加代码将评价内容发送到服务器
        // ...

        // 显示感谢消息
        alert('感谢您的评价！');

        // 清空表单
        form.reset();
    };
});

